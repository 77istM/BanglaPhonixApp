package com.example.bengalialphabetapp

import com.example.bengalialphabetapp.data.BengaliCharacter
import com.example.bengalialphabetapp.data.GuidanceLevel
import com.example.bengalialphabetapp.data.Point
import com.example.bengalialphabetapp.data.Stroke
import com.example.bengalialphabetapp.utils.PathUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the Bengali alphabet data models
 */
class AlphabetModelTest {

    @Test
    fun testStrokeToPath() {
        // Create a simple stroke
        val stroke = Stroke(
            id = 1,
            path = "M 10,10 L 50,50",
            startPoint = Point(10f, 10f),
            endPoint = Point(50f, 50f),
            controlPoints = listOf()
        )
        
        // Convert to path
        val path = PathUtils.strokeToPath(stroke)
        
        // Path should not be empty
        assertTrue(path != null)
    }
    
    @Test
    fun testGuidanceLevelProgression() {
        // Test guidance level progression
        val none = GuidanceLevel.NONE
        val dotsOnly = GuidanceLevel.DOTS_ONLY
        val dotsAndArrows = GuidanceLevel.DOTS_AND_ARROWS
        val fullPath = GuidanceLevel.FULL_PATH
        
        // Check ordinal values for progression
        assertTrue(none.ordinal < dotsOnly.ordinal)
        assertTrue(dotsOnly.ordinal < dotsAndArrows.ordinal)
        assertTrue(dotsAndArrows.ordinal < fullPath.ordinal)
    }
    
    @Test
    fun testBengaliCharacterCreation() {
        // Create a simple Bengali character
        val character = BengaliCharacter(
            id = "vowel_a",
            character = "অ",
            romanized = "a",
            pronunciation = "ô",
            description = "First vowel of Bengali alphabet",
            difficulty = 1,
            strokes = listOf(
                Stroke(
                    id = 1,
                    path = "M 10,10 L 50,50",
                    startPoint = Point(10f, 10f),
                    endPoint = Point(50f, 50f),
                    controlPoints = listOf()
                )
            ),
            guidanceDots = listOf(
                com.example.bengalialphabetapp.data.GuidanceDot(10f, 10f, 1),
                com.example.bengalialphabetapp.data.GuidanceDot(50f, 50f, 2)
            )
        )
        
        // Check character properties
        assertEquals("vowel_a", character.id)
        assertEquals("অ", character.character)
        assertEquals("a", character.romanized)
        assertEquals(1, character.strokes.size)
        assertEquals(2, character.guidanceDots.size)
    }
}


package com.example.bengalialphabetapp

import android.graphics.Path
import com.example.bengalialphabetapp.data.Point
import com.example.bengalialphabetapp.data.Stroke
import com.example.bengalialphabetapp.utils.GestureRecognizer
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.mock

/**
 * Unit tests for the gesture recognition system
 */
class GestureRecognizerTest {

    private lateinit var gestureRecognizer: GestureRecognizer
    
    @Before
    fun setUp() {
        gestureRecognizer = GestureRecognizer()
    }
    
    @Test
    fun testPerfectStrokeRecognition() {
        // Create a simple stroke
        val stroke = Stroke(
            id = 1,
            path = "M 10,10 L 50,50",
            startPoint = Point(10f, 10f),
            endPoint = Point(50f, 50f),
            controlPoints = listOf()
        )
        
        // Create a perfect path that matches the stroke
        val path = Path()
        path.moveTo(10f, 10f)
        path.lineTo(50f, 50f)
        
        // Recognize the stroke
        val result = gestureRecognizer.recognizeStroke(path, stroke)
        
        // Should be recognized as completed
        assertTrue(result.isCompleted)
        assertTrue(result.score > 90f) // High score for perfect match
    }
    
    @Test
    fun testBadStrokeRecognition() {
        // Create a simple stroke
        val stroke = Stroke(
            id = 1,
            path = "M 10,10 L 50,50",
            startPoint = Point(10f, 10f),
            endPoint = Point(50f, 50f),
            controlPoints = listOf()
        )
        
        // Create a path that doesn't match the stroke
        val path = Path()
        path.moveTo(10f, 10f)
        path.lineTo(50f, 10f) // Horizontal instead of diagonal
        
        // Recognize the stroke
        val result = gestureRecognizer.recognizeStroke(path, stroke)
        
        // Should not be recognized as completed
        assertFalse(result.isCompleted)
        assertTrue(result.score < 70f) // Low score for bad match
    }
    
    @Test
    fun testFeedbackGeneration() {
        // Create a simple stroke
        val stroke = Stroke(
            id = 1,
            path = "M 10,10 L 50,50",
            startPoint = Point(10f, 10f),
            endPoint = Point(50f, 50f),
            controlPoints = listOf()
        )
        
        // Create a path that doesn't match the stroke
        val path = Path()
        path.moveTo(20f, 10f) // Wrong start point
        path.lineTo(60f, 50f) // Wrong end point
        
        // Recognize the stroke
        val result = gestureRecognizer.recognizeStroke(path, stroke)
        
        // Should have feedback
        assertTrue(result.feedback.isNotEmpty())
    }
}


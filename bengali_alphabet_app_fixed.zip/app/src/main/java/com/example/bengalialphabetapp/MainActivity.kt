package com.example.bengalialphabetapp

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.bengalialphabetapp.data.GuidanceLevel
import com.example.bengalialphabetapp.databinding.ActivityMainBinding
import com.example.bengalialphabetapp.ui.DrawingViewModel
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: DrawingViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize view binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Initialize view model
        viewModel = ViewModelProvider(this)[DrawingViewModel::class.java]
        
        // Set up UI components
        setupUI()
        
        // Observe view model data
        observeViewModel()
    }
    
    private fun setupUI() {
        // Set up drawing view
        binding.drawingView.setOnStrokeCompletedListener { strokeIndex, score ->
            viewModel.onStrokeCompleted(strokeIndex, score)
        }
        
        binding.drawingView.setOnStrokeFailedListener { strokeIndex, score, feedback ->
            viewModel.onStrokeFailed(strokeIndex, score, feedback)
        }
        
        binding.drawingView.setOnCharacterCompletedListener {
            viewModel.onCharacterCompleted()
        }
        
        // Set up buttons
        binding.btnNext.setOnClickListener {
            viewModel.nextCharacter()
        }
        
        binding.btnPrevious.setOnClickListener {
            viewModel.previousCharacter()
        }
        
        binding.btnClear.setOnClickListener {
            binding.drawingView.resetDrawing()
        }
        
        binding.btnShowHint.setOnClickListener {
            // Cycle through guidance levels
            val currentLevel = viewModel.guidanceLevel.value ?: GuidanceLevel.DOTS_ONLY
            val nextLevel = when (currentLevel) {
                GuidanceLevel.NONE -> GuidanceLevel.DOTS_ONLY
                GuidanceLevel.DOTS_ONLY -> GuidanceLevel.DOTS_AND_ARROWS
                GuidanceLevel.DOTS_AND_ARROWS -> GuidanceLevel.FULL_PATH
                GuidanceLevel.FULL_PATH -> GuidanceLevel.NONE
            }
            viewModel.setGuidanceLevel(nextLevel)
        }
        
        binding.btnMicrophone.setOnClickListener {
            // TODO: Implement audio recording and playback
            Toast.makeText(this, "Microphone functionality coming soon!", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun observeViewModel() {
        // Observe current character
        viewModel.currentCharacter.observe(this) { character ->
            binding.tvTopic.text = character.romanized
            binding.drawingView.setCharacter(character)
            
            // Enable/disable navigation buttons
            binding.btnNext.isEnabled = true
            binding.btnPrevious.isEnabled = true
        }
        
        // Observe guidance level
        viewModel.guidanceLevel.observe(this) { guidanceLevel ->
            binding.drawingView.setGuidanceLevel(guidanceLevel)
            
            // Update hint button text based on guidance level
            val hintText = when (guidanceLevel) {
                GuidanceLevel.NONE -> getString(R.string.show_hint)
                GuidanceLevel.DOTS_ONLY -> getString(R.string.show_arrows)
                GuidanceLevel.DOTS_AND_ARROWS -> getString(R.string.show_full_path)
                GuidanceLevel.FULL_PATH -> getString(R.string.hide_hints)
            }
            binding.btnShowHint.text = hintText
        }
        
        // Observe stroke completion status
        viewModel.strokeCompletionStatus.observe(this) { status ->
            if (status.isCompleted) {
                // Show success feedback
                Snackbar.make(binding.root, "Stroke completed!", Snackbar.LENGTH_SHORT).show()
            }
        }
        
        // Observe character completion status
        viewModel.characterCompleted.observe(this) { isCompleted ->
            if (isCompleted) {
                // Show completion feedback
                Snackbar.make(binding.root, "Character completed! Great job!", Snackbar.LENGTH_LONG).show()
                
                // Enable next button
                binding.btnNext.isEnabled = true
            }
        }
        
        // Observe feedback message
        viewModel.feedbackMessage.observe(this) { message ->
            // Show feedback message
            if (message.isNotEmpty()) {
                Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        binding.drawingView.release()
    }
}


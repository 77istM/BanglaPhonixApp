package com.example.bengalialphabetapp.utils

import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PointF
import com.example.bengalialphabetapp.data.Point
import com.example.bengalialphabetapp.data.Stroke
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Utility class for gesture recognition and stroke validation
 */
class GestureRecognizer {

    /**
     * Validate a user-drawn path against a target stroke
     * @return Recognition result with score and feedback
     */
    fun recognizeStroke(userPath: Path, targetStroke: Stroke): RecognitionResult {
        val targetPath = PathUtils.strokeToPath(targetStroke)
        
        // Sample points along the user path
        val userPoints = samplePathPoints(userPath, SAMPLE_POINTS_COUNT)
        
        // Sample points along the target path
        val targetPoints = samplePathPoints(targetPath, SAMPLE_POINTS_COUNT)
        
        // Calculate direction similarity
        val directionSimilarity = calculateDirectionSimilarity(userPoints, targetPoints)
        
        // Calculate shape similarity
        val shapeSimilarity = calculateShapeSimilarity(userPoints, targetPoints)
        
        // Calculate start and end point accuracy
        val startPointAccuracy = calculatePointAccuracy(userPoints.first(), targetStroke.startPoint.toPointF())
        val endPointAccuracy = calculatePointAccuracy(userPoints.last(), targetStroke.endPoint.toPointF())
        
        // Calculate overall score
        val overallScore = (
            DIRECTION_WEIGHT * directionSimilarity +
            SHAPE_WEIGHT * shapeSimilarity +
            START_POINT_WEIGHT * startPointAccuracy +
            END_POINT_WEIGHT * endPointAccuracy
        ) / (DIRECTION_WEIGHT + SHAPE_WEIGHT + START_POINT_WEIGHT + END_POINT_WEIGHT)
        
        // Determine if the stroke is completed
        val isCompleted = overallScore >= COMPLETION_THRESHOLD
        
        // Generate feedback
        val feedback = generateFeedback(
            directionSimilarity,
            shapeSimilarity,
            startPointAccuracy,
            endPointAccuracy,
            isCompleted
        )
        
        return RecognitionResult(
            score = overallScore,
            isCompleted = isCompleted,
            feedback = feedback,
            directionSimilarity = directionSimilarity,
            shapeSimilarity = shapeSimilarity,
            startPointAccuracy = startPointAccuracy,
            endPointAccuracy = endPointAccuracy
        )
    }
    
    /**
     * Sample points along a path
     */
    private fun samplePathPoints(path: Path, count: Int): List<PointF> {
        val points = mutableListOf<PointF>()
        val pathMeasure = PathMeasure(path, false)
        val pathLength = pathMeasure.length
        
        if (pathLength <= 0) {
            return points
        }
        
        val step = pathLength / (count - 1)
        val pos = FloatArray(2)
        
        for (i in 0 until count) {
            val distance = i * step
            if (distance <= pathLength) {
                pathMeasure.getPosTan(distance, pos, null)
                points.add(PointF(pos[0], pos[1]))
            }
        }
        
        return points
    }
    
    /**
     * Calculate direction similarity between two point sequences
     */
    private fun calculateDirectionSimilarity(userPoints: List<PointF>, targetPoints: List<PointF>): Float {
        if (userPoints.size < 2 || targetPoints.size < 2) {
            return 0f
        }
        
        var totalSimilarity = 0f
        val count = minOf(userPoints.size - 1, targetPoints.size - 1)
        
        for (i in 0 until count) {
            val userDirection = calculateDirection(userPoints[i], userPoints[i + 1])
            val targetDirection = calculateDirection(targetPoints[i], targetPoints[i + 1])
            
            val directionDiff = abs(userDirection - targetDirection)
            val normalizedDiff = if (directionDiff > 180) 360 - directionDiff else directionDiff
            
            val similarity = 1 - (normalizedDiff / 180)
            totalSimilarity += similarity
        }
        
        return (totalSimilarity / count) * 100
    }
    
    /**
     * Calculate direction angle between two points (in degrees)
     */
    private fun calculateDirection(p1: PointF, p2: PointF): Float {
        val dx = p2.x - p1.x
        val dy = p2.y - p1.y
        
        val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
        return (angle + 360) % 360
    }
    
    /**
     * Calculate shape similarity using Dynamic Time Warping (DTW)
     */
    private fun calculateShapeSimilarity(userPoints: List<PointF>, targetPoints: List<PointF>): Float {
        if (userPoints.isEmpty() || targetPoints.isEmpty()) {
            return 0f
        }
        
        val m = userPoints.size
        val n = targetPoints.size
        
        // Create DTW matrix
        val dtw = Array(m) { FloatArray(n) { Float.MAX_VALUE } }
        
        // Initialize first cell
        dtw[0][0] = distance(userPoints[0], targetPoints[0])
        
        // Fill the DTW matrix
        for (i in 1 until m) {
            for (j in 1 until n) {
                val cost = distance(userPoints[i], targetPoints[j])
                dtw[i][j] = cost + minOf(dtw[i-1][j], dtw[i][j-1], dtw[i-1][j-1])
            }
        }
        
        // Get the DTW distance
        val dtwDistance = dtw[m-1][n-1]
        
        // Normalize and convert to similarity score (0-100)
        val maxPossibleDistance = 100f * sqrt(2f) // Assuming normalized coordinates
        val similarity = (1 - (dtwDistance / maxPossibleDistance)).coerceIn(0f, 1f) * 100
        
        return similarity
    }
    
    /**
     * Calculate accuracy of a point compared to a target point
     */
    private fun calculatePointAccuracy(point: PointF, targetPoint: PointF): Float {
        val dist = distance(point, targetPoint)
        val maxDistance = 100f // Assuming normalized coordinates
        
        return (1 - (dist / maxDistance).coerceIn(0f, 1f)) * 100
    }
    
    /**
     * Calculate distance between two points
     */
    private fun distance(p1: PointF, p2: PointF): Float {
        return sqrt((p2.x - p1.x).pow(2) + (p2.y - p1.y).pow(2))
    }
    
    /**
     * Generate feedback based on recognition results
     */
    private fun generateFeedback(
        directionSimilarity: Float,
        shapeSimilarity: Float,
        startPointAccuracy: Float,
        endPointAccuracy: Float,
        isCompleted: Boolean
    ): String {
        if (isCompleted) {
            return "Great job! Stroke completed correctly."
        }
        
        val feedbackList = mutableListOf<String>()
        
        if (startPointAccuracy < 70) {
            feedbackList.add("Start from the correct position.")
        }
        
        if (endPointAccuracy < 70) {
            feedbackList.add("Make sure to end at the right position.")
        }
        
        if (directionSimilarity < 70) {
            feedbackList.add("Follow the correct stroke direction.")
        }
        
        if (shapeSimilarity < 70) {
            feedbackList.add("Try to match the shape more closely.")
        }
        
        return if (feedbackList.isEmpty()) {
            "Almost there! Try again."
        } else {
            feedbackList.joinToString(" ")
        }
    }
    
    /**
     * Data class for recognition result
     */
    data class RecognitionResult(
        val score: Float,
        val isCompleted: Boolean,
        val feedback: String,
        val directionSimilarity: Float,
        val shapeSimilarity: Float,
        val startPointAccuracy: Float,
        val endPointAccuracy: Float
    )
    
    companion object {
        private const val SAMPLE_POINTS_COUNT = 20
        private const val COMPLETION_THRESHOLD = 70f
        
        // Weights for different aspects of stroke recognition
        private const val DIRECTION_WEIGHT = 0.3f
        private const val SHAPE_WEIGHT = 0.3f
        private const val START_POINT_WEIGHT = 0.2f
        private const val END_POINT_WEIGHT = 0.2f
    }
}


package com.example.bengalialphabetapp.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bengalialphabetapp.MainActivity
import com.example.bengalialphabetapp.databinding.ActivityTopicSelectionBinding
import com.example.bengalialphabetapp.utils.PreferenceUtils

/**
 * Activity for selecting a topic to practice
 */
class TopicSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTopicSelectionBinding
    private lateinit var preferenceUtils: PreferenceUtils
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize view binding
        binding = ActivityTopicSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Initialize preferences
        preferenceUtils = PreferenceUtils(this)
        
        // Set up topic cards
        setupTopicCards()
    }
    
    private fun setupTopicCards() {
        // Set up vowels card
        binding.cardVowels.setOnClickListener {
            navigateToMainActivity("vowels")
        }
        
        // Set up consonants card
        binding.cardConsonants.setOnClickListener {
            navigateToMainActivity("consonants")
        }
        
        // Set up numbers card
        binding.cardNumbers.setOnClickListener {
            navigateToMainActivity("numbers")
        }
        
        // Set up compound letters card
        binding.cardCompoundLetters.setOnClickListener {
            navigateToMainActivity("compound_letters")
        }
        
        // Update progress bars based on user progress
        updateProgressBars()
    }
    
    private fun updateProgressBars() {
        // Get all character progress
        val progressMap = preferenceUtils.getCharacterProgressMap()
        
        // Calculate progress for each category
        val vowelsProgress = calculateCategoryProgress(progressMap, "vowel_")
        val consonantsProgress = calculateCategoryProgress(progressMap, "consonant_")
        val numbersProgress = calculateCategoryProgress(progressMap, "number_")
        val compoundProgress = calculateCategoryProgress(progressMap, "compound_")
        
        // Update progress bars
        binding.progressVowels.progress = vowelsProgress
        binding.progressConsonants.progress = consonantsProgress
        binding.progressNumbers.progress = numbersProgress
        binding.progressCompoundLetters.progress = compoundProgress
    }
    
    private fun calculateCategoryProgress(progressMap: Map<String, com.example.bengalialphabetapp.data.CharacterProgress>, prefix: String): Int {
        // Count completed characters in this category
        val completedCount = progressMap.count { (id, progress) ->
            id.startsWith(prefix) && progress.completedCount > 0
        }
        
        // Estimate total characters in this category
        val totalCount = when (prefix) {
            "vowel_" -> 11
            "consonant_" -> 39
            "number_" -> 10
            "compound_" -> 20
            else -> 10
        }
        
        // Calculate percentage
        return if (totalCount > 0) {
            (completedCount * 100) / totalCount
        } else {
            0
        }
    }
    
    private fun navigateToMainActivity(category: String) {
        // Save selected category
        preferenceUtils.setCurrentCategory(category)
        
        // Navigate to main activity
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}


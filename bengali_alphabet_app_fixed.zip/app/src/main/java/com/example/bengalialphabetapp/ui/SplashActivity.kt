package com.example.bengalialphabetapp.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.example.bengalialphabetapp.MainActivity
import com.example.bengalialphabetapp.R
import com.example.bengalialphabetapp.databinding.ActivitySplashBinding

/**
 * Splash screen activity shown when the app starts
 */
class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize view binding
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Apply animations
        val fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in)
        val slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up)
        
        binding.ivLogo.startAnimation(fadeIn)
        binding.tvAppName.startAnimation(slideUp)
        binding.tvTagline.startAnimation(slideUp)
        
        // Navigate to main activity after delay
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, TopicSelectionActivity::class.java)
            startActivity(intent)
            finish()
        }, SPLASH_DELAY)
    }
    
    companion object {
        private const val SPLASH_DELAY = 2000L // 2 seconds
    }
}


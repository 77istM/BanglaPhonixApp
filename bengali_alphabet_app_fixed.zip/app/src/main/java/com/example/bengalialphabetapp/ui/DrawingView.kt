package com.example.bengalialphabetapp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.bengalialphabetapp.R
import com.example.bengalialphabetapp.data.BengaliCharacter
import com.example.bengalialphabetapp.data.GuidanceLevel
import com.example.bengalialphabetapp.data.Stroke
import com.example.bengalialphabetapp.utils.FeedbackManager
import com.example.bengalialphabetapp.utils.GestureRecognizer
import com.example.bengalialphabetapp.utils.PathUtils
import kotlin.math.min

/**
 * Custom view for drawing Bengali alphabet characters
 */
class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Character data
    private var character: BengaliCharacter? = null
    
    // Current stroke being drawn
    private var currentStrokeIndex = 0
    private var currentPath = Path()
    private val userPaths = mutableListOf<Path>()
    private val userPathResults = mutableListOf<GestureRecognizer.RecognitionResult>()
    
    // Drawing state
    private var isDrawing = false
    private var lastPoint = PointF()
    private var startPoint = PointF()
    
    // Guidance level
    private var guidanceLevel = GuidanceLevel.DOTS_ONLY
    
    // Feedback manager
    private val feedbackManager = FeedbackManager(context)
    
    // Completion tracking
    private val strokeCompletionPercentages = mutableListOf<Float>()
    
    // Callback for stroke completion
    private var onStrokeCompletedListener: ((Int, Float) -> Unit)? = null
    private var onStrokeFailedListener: ((Int, Float, String) -> Unit)? = null
    private var onCharacterCompletedListener: (() -> Unit)? = null
    
    // Paint objects
    private val outlinePaint = Paint().apply {
        color = Color.GRAY
        style = Paint.Style.STROKE
        strokeWidth = resources.getDimension(R.dimen.stroke_width) / 2
        isAntiAlias = true
    }
    
    private val strokePaint = Paint().apply {
        color = context.getColor(R.color.stroke_color)
        style = Paint.Style.STROKE
        strokeWidth = resources.getDimension(R.dimen.stroke_width)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }
    
    private val fillPaint = Paint().apply {
        color = context.getColor(R.color.stroke_fill)
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    
    /**
     * Set the character to be drawn
     */
    fun setCharacter(character: BengaliCharacter) {
        this.character = character
        resetDrawing()
        invalidate()
    }
    
    /**
     * Set the guidance level
     */
    fun setGuidanceLevel(level: GuidanceLevel) {
        this.guidanceLevel = level
        invalidate()
    }
    
    /**
     * Reset the drawing
     */
    fun resetDrawing() {
        currentStrokeIndex = 0
        currentPath = Path()
        userPaths.clear()
        userPathResults.clear()
        strokeCompletionPercentages.clear()
        character?.strokes?.forEach { _ ->
            strokeCompletionPercentages.add(0f)
        }
        isDrawing = false
        invalidate()
    }
    
    /**
     * Set the stroke completed listener
     */
    fun setOnStrokeCompletedListener(listener: (Int, Float) -> Unit) {
        onStrokeCompletedListener = listener
    }
    
    /**
     * Set the stroke failed listener
     */
    fun setOnStrokeFailedListener(listener: (Int, Float, String) -> Unit) {
        onStrokeFailedListener = listener
    }
    
    /**
     * Set the character completed listener
     */
    fun setOnCharacterCompletedListener(listener: () -> Unit) {
        onCharacterCompletedListener = listener
    }
    
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        character?.let { char ->
            // Calculate scale factor to fit the character in the view
            val scaleFactor = calculateScaleFactor(char)
            
            // Draw character outline
            drawCharacterOutline(canvas, char, scaleFactor)
            
            // Draw filled strokes for completed strokes
            for (i in 0 until currentStrokeIndex) {
                if (i < char.strokes.size) {
                    drawStroke(canvas, char.strokes[i], fillPaint, scaleFactor)
                }
            }
            
            // Draw guidance elements based on the current guidance level
            if (currentStrokeIndex < char.strokes.size) {
                feedbackManager.drawGuidance(canvas, char, currentStrokeIndex, guidanceLevel, scaleFactor)
            }
            
            // Draw user paths with feedback
            for (i in userPaths.indices) {
                val isCorrect = userPathResults.getOrNull(i)?.isCompleted ?: false
                feedbackManager.drawStrokeFeedback(canvas, userPaths[i], isCorrect, scaleFactor)
            }
            
            // Draw current path
            if (isDrawing) {
                canvas.save()
                canvas.scale(scaleFactor, scaleFactor, 0f, 0f)
                canvas.drawPath(currentPath, strokePaint)
                canvas.restore()
            }
        }
    }
    
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (character == null || currentStrokeIndex >= (character?.strokes?.size ?: 0)) {
            return false
        }
        
        val scaleFactor = calculateScaleFactor(character!!)
        val x = event.x / scaleFactor
        val y = event.y / scaleFactor
        val point = PointF(x, y)
        
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startPoint = point
                lastPoint = point
                currentPath = Path()
                currentPath.moveTo(x, y)
                isDrawing = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDrawing) {
                    // Add point to path
                    currentPath.quadTo(
                        lastPoint.x, lastPoint.y,
                        (lastPoint.x + point.x) / 2, (lastPoint.y + point.y) / 2
                    )
                    lastPoint = point
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (isDrawing) {
                    // Finalize the path
                    currentPath.lineTo(point.x, point.y)
                    
                    // Validate the stroke
                    val currentStroke = character!!.strokes[currentStrokeIndex]
                    val result = feedbackManager.recognizeStroke(currentPath, currentStroke)
                    
                    // Update completion percentage
                    strokeCompletionPercentages[currentStrokeIndex] = result.score
                    
                    // Add to user paths
                    userPaths.add(Path(currentPath))
                    userPathResults.add(result)
                    
                    // Check if stroke is completed
                    if (result.isCompleted) {
                        // Notify listener
                        onStrokeCompletedListener?.invoke(currentStrokeIndex, result.score)
                        
                        // Move to next stroke
                        currentStrokeIndex++
                        
                        // Check if character is completed
                        if (currentStrokeIndex >= character!!.strokes.size) {
                            onCharacterCompletedListener?.invoke()
                        }
                    } else {
                        // Notify failed listener
                        onStrokeFailedListener?.invoke(currentStrokeIndex, result.score, result.feedback)
                    }
                    
                    isDrawing = false
                    invalidate()
                }
                return true
            }
        }
        
        return super.onTouchEvent(event)
    }
    
    /**
     * Calculate scale factor to fit the character in the view
     */
    private fun calculateScaleFactor(character: BengaliCharacter): Float {
        // Find the bounds of the character
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE
        var maxY = Float.MIN_VALUE
        
        character.strokes.forEach { stroke ->
            minX = min(minX, stroke.startPoint.x)
            minY = min(minY, stroke.startPoint.y)
            maxX = maxOf(maxX, stroke.startPoint.x)
            maxY = maxOf(maxY, stroke.startPoint.y)
            
            minX = min(minX, stroke.endPoint.x)
            minY = min(minY, stroke.endPoint.y)
            maxX = maxOf(maxX, stroke.endPoint.x)
            maxY = maxOf(maxY, stroke.endPoint.y)
            
            stroke.controlPoints.forEach { point ->
                minX = min(minX, point.x)
                minY = min(minY, point.y)
                maxX = maxOf(maxX, point.x)
                maxY = maxOf(maxY, point.y)
            }
        }
        
        // Calculate scale factor
        val characterWidth = maxX - minX
        val characterHeight = maxY - minY
        
        val scaleX = width / characterWidth
        val scaleY = height / characterHeight
        
        // Use the smaller scale factor to ensure the character fits
        return min(scaleX, scaleY) * 0.8f // 80% of the view size for padding
    }
    
    /**
     * Draw the character outline
     */
    private fun drawCharacterOutline(canvas: Canvas, character: BengaliCharacter, scaleFactor: Float) {
        canvas.save()
        canvas.scale(scaleFactor, scaleFactor, 0f, 0f)
        
        character.strokes.forEach { stroke ->
            drawStroke(canvas, stroke, outlinePaint, 1f)
        }
        
        canvas.restore()
    }
    
    /**
     * Draw a stroke with the specified paint
     */
    private fun drawStroke(canvas: Canvas, stroke: Stroke, paint: Paint, scaleFactor: Float) {
        val path = PathUtils.strokeToPath(stroke)
        
        canvas.save()
        canvas.scale(scaleFactor, scaleFactor, 0f, 0f)
        canvas.drawPath(path, paint)
        canvas.restore()
    }
    
    /**
     * Clean up resources
     */
    fun release() {
        feedbackManager.release()
    }
}


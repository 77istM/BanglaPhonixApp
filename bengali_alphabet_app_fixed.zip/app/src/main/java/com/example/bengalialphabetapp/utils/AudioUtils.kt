package com.example.bengalialphabetapp.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.io.File
import java.io.IOException

/**
 * Utility class for audio feedback and pronunciation
 */
class AudioUtils(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var isRecording = false
    
    /**
     * Play a sound effect
     */
    fun playSoundEffect(soundType: SoundType) {
        val resourceId = when (soundType) {
            SoundType.CORRECT -> android.R.raw.notification_simple_01
            SoundType.INCORRECT -> android.R.raw.notification_simple_02
            SoundType.COMPLETE -> android.R.raw.notification_simple_03
        }
        
        try {
            stopPlayback()
            
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .build()
                )
                setDataSource(context.resources.openRawResourceFd(resourceId))
                prepare()
                start()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
    
    /**
     * Play a pronunciation audio file
     */
    fun playPronunciation(audioFilePath: String) {
        try {
            stopPlayback()
            
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(audioFilePath)
                prepare()
                start()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
    
    /**
     * Start recording audio
     */
    fun startRecording(outputFile: File): Boolean {
        if (isRecording) {
            stopRecording()
        }
        
        return try {
            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }
            
            isRecording = true
            true
        } catch (e: IOException) {
            e.printStackTrace()
            false
        }
    }
    
    /**
     * Stop recording audio
     */
    fun stopRecording() {
        if (isRecording) {
            try {
                mediaRecorder?.apply {
                    stop()
                    release()
                }
                mediaRecorder = null
                isRecording = false
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Stop any ongoing playback
     */
    fun stopPlayback() {
        mediaPlayer?.apply {
            if (isPlaying) {
                stop()
            }
            release()
        }
        mediaPlayer = null
    }
    
    /**
     * Provide haptic feedback
     */
    fun provideHapticFeedback(feedbackType: HapticFeedbackType) {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val effect = when (feedbackType) {
                HapticFeedbackType.CORRECT -> VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE)
                HapticFeedbackType.INCORRECT -> VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE)
                HapticFeedbackType.COMPLETE -> VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE)
            }
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            val duration = when (feedbackType) {
                HapticFeedbackType.CORRECT -> 50L
                HapticFeedbackType.INCORRECT -> 100L
                HapticFeedbackType.COMPLETE -> 200L
            }
            vibrator.vibrate(duration)
        }
    }
    
    /**
     * Release resources
     */
    fun release() {
        stopRecording()
        stopPlayback()
    }
    
    /**
     * Sound effect types
     */
    enum class SoundType {
        CORRECT,
        INCORRECT,
        COMPLETE
    }
    
    /**
     * Haptic feedback types
     */
    enum class HapticFeedbackType {
        CORRECT,
        INCORRECT,
        COMPLETE
    }
}


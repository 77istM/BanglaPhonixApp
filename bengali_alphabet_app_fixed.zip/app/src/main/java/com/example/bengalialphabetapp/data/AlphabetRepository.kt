package com.example.bengalialphabetapp.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Repository class for managing Bengali alphabet data
 */
class AlphabetRepository(private val context: Context) {

    private val gson = Gson()
    
    // Cache for loaded categories
    private val categoryCache = mutableMapOf<String, AlphabetCategory>()
    
    /**
     * Get all available alphabet categories
     */
    suspend fun getCategories(): List<String> = withContext(Dispatchers.IO) {
        listOf("vowels", "consonants", "numbers", "compound_letters")
    }
    
    /**
     * Load a specific alphabet category
     */
    suspend fun loadCategory(categoryName: String): AlphabetCategory? = withContext(Dispatchers.IO) {
        // Return from cache if available
        categoryCache[categoryName]?.let { return@withContext it }
        
        try {
            val assetFileName = "alphabets/bengali_${categoryName}.json"
            val jsonString = context.assets.open(assetFileName).bufferedReader().use { it.readText() }
            
            val categoryType = object : TypeToken<AlphabetCategory>() {}.type
            val category = gson.fromJson<AlphabetCategory>(jsonString, categoryType)
            
            // Cache the loaded category
            categoryCache[categoryName] = category
            
            category
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
    
    /**
     * Get a specific character by ID
     */
    suspend fun getCharacterById(characterId: String): BengaliCharacter? = withContext(Dispatchers.IO) {
        // Search through all categories
        for (categoryName in getCategories()) {
            val category = loadCategory(categoryName) ?: continue
            val character = category.characters.find { it.id == characterId }
            if (character != null) {
                return@withContext character
            }
        }
        null
    }
    
    /**
     * Get the next character in a category
     */
    suspend fun getNextCharacter(categoryName: String, currentCharacterId: String?): BengaliCharacter? = withContext(Dispatchers.IO) {
        val category = loadCategory(categoryName) ?: return@withContext null
        
        if (currentCharacterId == null) {
            // Return the first character if no current character
            return@withContext category.characters.firstOrNull()
        }
        
        val currentIndex = category.characters.indexOfFirst { it.id == currentCharacterId }
        if (currentIndex == -1 || currentIndex >= category.characters.size - 1) {
            // Current character not found or is the last one
            return@withContext null
        }
        
        // Return the next character
        category.characters[currentIndex + 1]
    }
    
    /**
     * Get the previous character in a category
     */
    suspend fun getPreviousCharacter(categoryName: String, currentCharacterId: String?): BengaliCharacter? = withContext(Dispatchers.IO) {
        val category = loadCategory(categoryName) ?: return@withContext null
        
        if (currentCharacterId == null) {
            // Return the last character if no current character
            return@withContext category.characters.lastOrNull()
        }
        
        val currentIndex = category.characters.indexOfFirst { it.id == currentCharacterId }
        if (currentIndex <= 0) {
            // Current character not found or is the first one
            return@withContext null
        }
        
        // Return the previous character
        category.characters[currentIndex - 1]
    }
}


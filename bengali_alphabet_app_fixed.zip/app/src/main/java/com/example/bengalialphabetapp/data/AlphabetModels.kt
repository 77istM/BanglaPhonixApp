package com.example.bengalialphabetapp.data

import android.graphics.PointF
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Data class representing a category of Bengali characters (vowels, consonants, etc.)
 */
@Parcelize
data class AlphabetCategory(
    val category: String,
    val title: String,
    val description: String,
    val characters: List<BengaliCharacter>
) : Parcelable

/**
 * Data class representing a Bengali character with its properties and stroke information
 */
@Parcelize
data class BengaliCharacter(
    val id: String,
    val character: String,
    val romanized: String,
    val pronunciation: String,
    val description: String,
    val difficulty: Int,
    val strokes: List<Stroke>,
    val guidanceDots: List<GuidanceDot>
) : Parcelable

/**
 * Data class representing a stroke in a Bengali character
 */
@Parcelize
data class Stroke(
    val id: Int,
    val path: String,
    val startPoint: Point,
    val endPoint: Point,
    val controlPoints: List<Point>
) : Parcelable

/**
 * Data class representing a point in 2D space
 */
@Parcelize
data class Point(
    val x: Float,
    val y: Float
) : Parcelable {
    fun toPointF(): PointF = PointF(x, y)
}

/**
 * Data class representing a guidance dot for drawing assistance
 */
@Parcelize
data class GuidanceDot(
    val x: Float,
    val y: Float,
    val order: Int
) : Parcelable {
    fun toPoint(): Point = Point(x, y)
    fun toPointF(): PointF = PointF(x, y)
}

/**
 * Data class representing user progress for a specific character
 */
data class CharacterProgress(
    val characterId: String,
    val attemptsCount: Int,
    val completedCount: Int,
    val lastAttemptTimestamp: Long,
    val masteryLevel: MasteryLevel
)

/**
 * Enum representing the mastery level of a character
 */
enum class MasteryLevel {
    NOT_STARTED,
    BEGINNER,
    INTERMEDIATE,
    ADVANCED,
    MASTERED
}

/**
 * Enum representing the guidance level to show to the user
 */
enum class GuidanceLevel {
    NONE,           // No guidance
    DOTS_ONLY,      // Show only dots
    DOTS_AND_ARROWS, // Show dots and arrows
    FULL_PATH       // Show full path with dots and arrows
}


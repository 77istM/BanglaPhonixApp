package com.example.bengalialphabetapp.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.bengalialphabetapp.data.AlphabetRepository
import com.example.bengalialphabetapp.data.BengaliCharacter
import com.example.bengalialphabetapp.data.GuidanceLevel
import com.example.bengalialphabetapp.data.MasteryLevel
import com.example.bengalialphabetapp.utils.AudioUtils
import com.example.bengalialphabetapp.utils.PreferenceUtils
import kotlinx.coroutines.launch

/**
 * ViewModel for managing drawing state and character data
 */
class DrawingViewModel(application: Application) : AndroidViewModel(application) {

    // Repositories and utilities
    private val repository = AlphabetRepository(application)
    private val preferenceUtils = PreferenceUtils(application)
    private val audioUtils = AudioUtils(application)
    
    // Current character data
    private val _currentCharacter = MutableLiveData<BengaliCharacter>()
    val currentCharacter: LiveData<BengaliCharacter> = _currentCharacter
    
    // Current category
    private val _currentCategory = MutableLiveData<String>()
    val currentCategory: LiveData<String> = _currentCategory
    
    // Guidance level
    private val _guidanceLevel = MutableLiveData<GuidanceLevel>()
    val guidanceLevel: LiveData<GuidanceLevel> = _guidanceLevel
    
    // Stroke completion status
    private val _strokeCompletionStatus = MutableLiveData<StrokeCompletionStatus>()
    val strokeCompletionStatus: LiveData<StrokeCompletionStatus> = _strokeCompletionStatus
    
    // Character completion status
    private val _characterCompleted = MutableLiveData<Boolean>()
    val characterCompleted: LiveData<Boolean> = _characterCompleted
    
    // Feedback message
    private val _feedbackMessage = MutableLiveData<String>()
    val feedbackMessage: LiveData<String> = _feedbackMessage
    
    // Failed attempts counter
    private var failedAttempts = 0
    
    init {
        // Load initial data
        _currentCategory.value = preferenceUtils.getCurrentCategory()
        _guidanceLevel.value = preferenceUtils.getGuidanceLevel()
        
        // Load current character
        loadCurrentCharacter()
    }
    
    /**
     * Load the current character
     */
    fun loadCurrentCharacter() {
        viewModelScope.launch {
            val categoryName = _currentCategory.value ?: return@launch
            val characterId = preferenceUtils.getCurrentCharacterId()
            
            val character = if (characterId != null) {
                repository.getCharacterById(characterId)
            } else {
                // Load the first character in the category
                repository.loadCategory(categoryName)?.characters?.firstOrNull()
            }
            
            character?.let {
                _currentCharacter.value = it
                preferenceUtils.setCurrentCharacterId(it.id)
                _characterCompleted.value = false
                _feedbackMessage.value = "Draw the character ${it.character} (${it.romanized})"
                failedAttempts = 0
            }
        }
    }
    
    /**
     * Move to the next character
     */
    fun nextCharacter() {
        viewModelScope.launch {
            val categoryName = _currentCategory.value ?: return@launch
            val currentCharacterId = _currentCharacter.value?.id ?: return@launch
            
            val nextCharacter = repository.getNextCharacter(categoryName, currentCharacterId)
            
            nextCharacter?.let {
                _currentCharacter.value = it
                preferenceUtils.setCurrentCharacterId(it.id)
                _characterCompleted.value = false
                _feedbackMessage.value = "Draw the character ${it.character} (${it.romanized})"
                failedAttempts = 0
            }
        }
    }
    
    /**
     * Move to the previous character
     */
    fun previousCharacter() {
        viewModelScope.launch {
            val categoryName = _currentCategory.value ?: return@launch
            val currentCharacterId = _currentCharacter.value?.id ?: return@launch
            
            val previousCharacter = repository.getPreviousCharacter(categoryName, currentCharacterId)
            
            previousCharacter?.let {
                _currentCharacter.value = it
                preferenceUtils.setCurrentCharacterId(it.id)
                _characterCompleted.value = false
                _feedbackMessage.value = "Draw the character ${it.character} (${it.romanized})"
                failedAttempts = 0
            }
        }
    }
    
    /**
     * Set the current category
     */
    fun setCategory(category: String) {
        _currentCategory.value = category
        preferenceUtils.setCurrentCategory(category)
        preferenceUtils.setCurrentCharacterId(null)
        loadCurrentCharacter()
    }
    
    /**
     * Handle stroke completion
     */
    fun onStrokeCompleted(strokeIndex: Int, score: Float) {
        // Reset failed attempts counter
        failedAttempts = 0
        
        // Play success sound
        if (preferenceUtils.isAudioFeedbackEnabled()) {
            audioUtils.playSoundEffect(AudioUtils.SoundType.CORRECT)
        }
        
        // Provide haptic feedback
        if (preferenceUtils.isHapticFeedbackEnabled()) {
            audioUtils.provideHapticFeedback(AudioUtils.HapticFeedbackType.CORRECT)
        }
        
        // Update stroke completion status
        _strokeCompletionStatus.value = StrokeCompletionStatus(
            strokeIndex = strokeIndex,
            score = score,
            isCompleted = true
        )
        
        // Update feedback message
        _feedbackMessage.value = "Good job! Continue to the next stroke."
    }
    
    /**
     * Handle character completion
     */
    fun onCharacterCompleted() {
        // Update character progress
        val characterId = _currentCharacter.value?.id ?: return
        preferenceUtils.updateCharacterProgress(
            characterId = characterId,
            completed = true,
            masteryLevel = MasteryLevel.INTERMEDIATE
        )
        
        // Play completion sound
        if (preferenceUtils.isAudioFeedbackEnabled()) {
            audioUtils.playSoundEffect(AudioUtils.SoundType.COMPLETE)
        }
        
        // Provide haptic feedback
        if (preferenceUtils.isHapticFeedbackEnabled()) {
            audioUtils.provideHapticFeedback(AudioUtils.HapticFeedbackType.COMPLETE)
        }
        
        // Update character completion status
        _characterCompleted.value = true
        
        // Update feedback message
        _feedbackMessage.value = "Excellent! You've completed the character ${_currentCharacter.value?.character}."
    }
    
    /**
     * Handle failed stroke attempt
     */
    fun onStrokeFailed(strokeIndex: Int, score: Float, feedback: String) {
        failedAttempts++
        
        // Play error sound
        if (preferenceUtils.isAudioFeedbackEnabled()) {
            audioUtils.playSoundEffect(AudioUtils.SoundType.INCORRECT)
        }
        
        // Provide haptic feedback
        if (preferenceUtils.isHapticFeedbackEnabled()) {
            audioUtils.provideHapticFeedback(AudioUtils.HapticFeedbackType.INCORRECT)
        }
        
        // Update stroke completion status
        _strokeCompletionStatus.value = StrokeCompletionStatus(
            strokeIndex = strokeIndex,
            score = score,
            isCompleted = false
        )
        
        // Update feedback message
        _feedbackMessage.value = feedback
        
        // Increase guidance level after multiple failed attempts
        if (failedAttempts >= FAILED_ATTEMPTS_THRESHOLD) {
            increaseGuidanceLevel()
        }
    }
    
    /**
     * Increase the guidance level
     */
    private fun increaseGuidanceLevel() {
        val currentLevel = _guidanceLevel.value ?: GuidanceLevel.DOTS_ONLY
        
        val newLevel = when (currentLevel) {
            GuidanceLevel.NONE -> GuidanceLevel.DOTS_ONLY
            GuidanceLevel.DOTS_ONLY -> GuidanceLevel.DOTS_AND_ARROWS
            GuidanceLevel.DOTS_AND_ARROWS -> GuidanceLevel.FULL_PATH
            GuidanceLevel.FULL_PATH -> GuidanceLevel.FULL_PATH // Already at max level
        }
        
        _guidanceLevel.value = newLevel
        preferenceUtils.setGuidanceLevel(newLevel)
        
        // Update feedback message
        _feedbackMessage.value = "Let me help you with more guidance."
    }
    
    /**
     * Set the guidance level
     */
    fun setGuidanceLevel(level: GuidanceLevel) {
        _guidanceLevel.value = level
        preferenceUtils.setGuidanceLevel(level)
    }
    
    /**
     * Clean up resources
     */
    override fun onCleared() {
        super.onCleared()
        audioUtils.release()
    }
    
    /**
     * Data class for stroke completion status
     */
    data class StrokeCompletionStatus(
        val strokeIndex: Int,
        val score: Float,
        val isCompleted: Boolean
    )
    
    companion object {
        private const val FAILED_ATTEMPTS_THRESHOLD = 3
    }
}


package com.example.bengalialphabetapp.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.bengalialphabetapp.data.CharacterProgress
import com.example.bengalialphabetapp.data.GuidanceLevel
import com.example.bengalialphabetapp.data.MasteryLevel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Utility class for managing user progress and preferences
 */
class PreferenceUtils(context: Context) {

    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        PREFERENCES_NAME, Context.MODE_PRIVATE
    )
    
    private val gson = Gson()
    
    /**
     * Save character progress
     */
    fun saveCharacterProgress(progress: CharacterProgress) {
        val progressMap = getCharacterProgressMap().toMutableMap()
        progressMap[progress.characterId] = progress
        
        val json = gson.toJson(progressMap)
        sharedPreferences.edit().putString(KEY_CHARACTER_PROGRESS, json).apply()
    }
    
    /**
     * Get progress for a specific character
     */
    fun getCharacterProgress(characterId: String): CharacterProgress {
        val progressMap = getCharacterProgressMap()
        
        return progressMap[characterId] ?: CharacterProgress(
            characterId = characterId,
            attemptsCount = 0,
            completedCount = 0,
            lastAttemptTimestamp = 0,
            masteryLevel = MasteryLevel.NOT_STARTED
        )
    }
    
    /**
     * Get all character progress
     */
    fun getCharacterProgressMap(): Map<String, CharacterProgress> {
        val json = sharedPreferences.getString(KEY_CHARACTER_PROGRESS, null) ?: return emptyMap()
        
        val type = object : TypeToken<Map<String, CharacterProgress>>() {}.type
        return gson.fromJson(json, type) ?: emptyMap()
    }
    
    /**
     * Update character progress after an attempt
     */
    fun updateCharacterProgress(
        characterId: String,
        completed: Boolean,
        masteryLevel: MasteryLevel? = null
    ) {
        val progress = getCharacterProgress(characterId)
        
        val updatedProgress = progress.copy(
            attemptsCount = progress.attemptsCount + 1,
            completedCount = if (completed) progress.completedCount + 1 else progress.completedCount,
            lastAttemptTimestamp = System.currentTimeMillis(),
            masteryLevel = masteryLevel ?: progress.masteryLevel
        )
        
        saveCharacterProgress(updatedProgress)
    }
    
    /**
     * Get the current guidance level preference
     */
    fun getGuidanceLevel(): GuidanceLevel {
        val levelOrdinal = sharedPreferences.getInt(KEY_GUIDANCE_LEVEL, GuidanceLevel.DOTS_ONLY.ordinal)
        return GuidanceLevel.values()[levelOrdinal]
    }
    
    /**
     * Set the guidance level preference
     */
    fun setGuidanceLevel(level: GuidanceLevel) {
        sharedPreferences.edit().putInt(KEY_GUIDANCE_LEVEL, level.ordinal).apply()
    }
    
    /**
     * Get the current category
     */
    fun getCurrentCategory(): String {
        return sharedPreferences.getString(KEY_CURRENT_CATEGORY, DEFAULT_CATEGORY) ?: DEFAULT_CATEGORY
    }
    
    /**
     * Set the current category
     */
    fun setCurrentCategory(category: String) {
        sharedPreferences.edit().putString(KEY_CURRENT_CATEGORY, category).apply()
    }
    
    /**
     * Get the current character ID
     */
    fun getCurrentCharacterId(): String? {
        return sharedPreferences.getString(KEY_CURRENT_CHARACTER_ID, null)
    }
    
    /**
     * Set the current character ID
     */
    fun setCurrentCharacterId(characterId: String?) {
        sharedPreferences.edit().putString(KEY_CURRENT_CHARACTER_ID, characterId).apply()
    }
    
    /**
     * Get whether audio feedback is enabled
     */
    fun isAudioFeedbackEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_AUDIO_FEEDBACK_ENABLED, true)
    }
    
    /**
     * Set whether audio feedback is enabled
     */
    fun setAudioFeedbackEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_AUDIO_FEEDBACK_ENABLED, enabled).apply()
    }
    
    /**
     * Get whether haptic feedback is enabled
     */
    fun isHapticFeedbackEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_HAPTIC_FEEDBACK_ENABLED, true)
    }
    
    /**
     * Set whether haptic feedback is enabled
     */
    fun setHapticFeedbackEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_HAPTIC_FEEDBACK_ENABLED, enabled).apply()
    }
    
    /**
     * Clear all preferences
     */
    fun clearAll() {
        sharedPreferences.edit().clear().apply()
    }
    
    companion object {
        private const val PREFERENCES_NAME = "bengali_alphabet_prefs"
        private const val KEY_CHARACTER_PROGRESS = "character_progress"
        private const val KEY_GUIDANCE_LEVEL = "guidance_level"
        private const val KEY_CURRENT_CATEGORY = "current_category"
        private const val KEY_CURRENT_CHARACTER_ID = "current_character_id"
        private const val KEY_AUDIO_FEEDBACK_ENABLED = "audio_feedback_enabled"
        private const val KEY_HAPTIC_FEEDBACK_ENABLED = "haptic_feedback_enabled"
        
        private const val DEFAULT_CATEGORY = "vowels"
    }
}


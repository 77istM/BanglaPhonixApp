package com.example.bengalialphabetapp.utils

import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PointF
import com.example.bengalialphabetapp.data.Point
import com.example.bengalialphabetapp.data.Stroke
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Utility class for path operations and stroke validation
 */
object PathUtils {

    /**
     * Convert a stroke to an Android Path object
     */
    fun strokeToPath(stroke: Stroke): Path {
        val path = Path()
        
        // Move to the start point
        path.moveTo(stroke.startPoint.x, stroke.startPoint.y)
        
        // If there are control points, create a cubic or quadratic bezier curve
        when (stroke.controlPoints.size) {
            0 -> {
                // Simple line
                path.lineTo(stroke.endPoint.x, stroke.endPoint.y)
            }
            1 -> {
                // Quadratic bezier curve
                val cp = stroke.controlPoints[0]
                path.quadTo(cp.x, cp.y, stroke.endPoint.x, stroke.endPoint.y)
            }
            2 -> {
                // Cubic bezier curve
                val cp1 = stroke.controlPoints[0]
                val cp2 = stroke.controlPoints[1]
                path.cubicTo(cp1.x, cp1.y, cp2.x, cp2.y, stroke.endPoint.x, stroke.endPoint.y)
            }
            else -> {
                // For more complex paths with multiple control points
                // We'll use a series of cubic bezier curves
                var prevPoint = stroke.startPoint
                
                for (i in 0 until stroke.controlPoints.size - 1 step 2) {
                    val cp1 = stroke.controlPoints[i]
                    
                    if (i + 1 < stroke.controlPoints.size) {
                        val cp2 = stroke.controlPoints[i + 1]
                        val endPoint = if (i + 2 < stroke.controlPoints.size) {
                            stroke.controlPoints[i + 2]
                        } else {
                            stroke.endPoint
                        }
                        
                        path.cubicTo(cp1.x, cp1.y, cp2.x, cp2.y, endPoint.x, endPoint.y)
                        prevPoint = endPoint
                    } else {
                        // If we have an odd number of control points, use the last one for a quadratic curve
                        path.quadTo(cp1.x, cp1.y, stroke.endPoint.x, stroke.endPoint.y)
                    }
                }
            }
        }
        
        return path
    }
    
    /**
     * Calculate the distance between two points
     */
    fun distance(p1: PointF, p2: PointF): Float {
        return sqrt((p2.x - p1.x).pow(2) + (p2.y - p1.y).pow(2))
    }
    
    /**
     * Calculate the distance between a point and a path
     */
    fun distanceToPath(point: PointF, path: Path, threshold: Float = 50f): Float {
        val pathMeasure = PathMeasure(path, false)
        val pathLength = pathMeasure.length
        val step = pathLength / 100 // Divide path into 100 segments
        
        var minDistance = Float.MAX_VALUE
        val pos = FloatArray(2)
        
        for (i in 0..100) {
            val distance = i * step
            pathMeasure.getPosTan(distance, pos, null)
            val pathPoint = PointF(pos[0], pos[1])
            val dist = distance(point, pathPoint)
            
            if (dist < minDistance) {
                minDistance = dist
            }
            
            // Early exit if we're close enough
            if (minDistance <= threshold) {
                return minDistance
            }
        }
        
        return minDistance
    }
    
    /**
     * Check if a user-drawn path matches a target stroke
     */
    fun validateStroke(userPath: Path, targetStroke: Stroke, tolerance: Float = 50f): Float {
        val targetPath = strokeToPath(targetStroke)
        
        // Sample points along the user path
        val userPathMeasure = PathMeasure(userPath, false)
        val userPathLength = userPathMeasure.length
        val step = userPathLength / 20 // Sample 20 points
        
        var totalDistance = 0f
        val pos = FloatArray(2)
        
        for (i in 0..20) {
            val distance = i * step
            if (distance <= userPathLength) {
                userPathMeasure.getPosTan(distance, pos, null)
                val point = PointF(pos[0], pos[1])
                
                // Calculate distance to target path
                val distToTarget = distanceToPath(point, targetPath)
                totalDistance += distToTarget
            }
        }
        
        // Calculate average distance (lower is better)
        val avgDistance = totalDistance / 21
        
        // Convert to a percentage score (0-100)
        val maxScore = 100f
        val score = maxScore * (1 - (avgDistance / tolerance).coerceIn(0f, 1f))
        
        return score
    }
    
    /**
     * Check if a point is near another point
     */
    fun isNearPoint(point: PointF, target: PointF, threshold: Float = 50f): Boolean {
        return distance(point, target) <= threshold
    }
    
    /**
     * Calculate the percentage of a stroke that has been completed
     */
    fun calculateStrokeCompletion(userPath: Path, targetStroke: Stroke): Float {
        val targetPath = strokeToPath(targetStroke)
        
        // Get the length of the target path
        val targetPathMeasure = PathMeasure(targetPath, false)
        val targetLength = targetPathMeasure.length
        
        // Get the length of the user path
        val userPathMeasure = PathMeasure(userPath, false)
        val userLength = userPathMeasure.length
        
        // Calculate the percentage of completion
        return (userLength / targetLength).coerceIn(0f, 1f) * 100f
    }
}


package com.example.bengalialphabetapp.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import com.example.bengalialphabetapp.R
import com.example.bengalialphabetapp.data.BengaliCharacter
import com.example.bengalialphabetapp.data.GuidanceLevel
import com.example.bengalialphabetapp.data.Stroke

/**
 * Manager class for providing visual and audio feedback during drawing
 */
class FeedbackManager(private val context: Context) {

    // Audio utilities
    private val audioUtils = AudioUtils(context)
    
    // Preference utilities
    private val preferenceUtils = PreferenceUtils(context)
    
    // Gesture recognizer
    private val gestureRecognizer = GestureRecognizer()
    
    // Paint objects for visual feedback
    private val correctPaint = Paint().apply {
        color = context.getColor(R.color.correct)
        style = Paint.Style.STROKE
        strokeWidth = context.resources.getDimension(R.dimen.stroke_width)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }
    
    private val incorrectPaint = Paint().apply {
        color = context.getColor(R.color.incorrect)
        style = Paint.Style.STROKE
        strokeWidth = context.resources.getDimension(R.dimen.stroke_width)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }
    
    private val guidancePaint = Paint().apply {
        color = context.getColor(R.color.guidance)
        style = Paint.Style.STROKE
        strokeWidth = context.resources.getDimension(R.dimen.stroke_width) / 2
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }
    
    private val guidanceDotPaint = Paint().apply {
        color = context.getColor(R.color.guidance)
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    
    private val textPaint = Paint().apply {
        color = context.getColor(R.color.guidance)
        textSize = context.resources.getDimension(R.dimen.text_size_small)
        isAntiAlias = true
    }
    
    // Animation properties
    private var animationHandler: Handler? = null
    private var animationRunnable: Runnable? = null
    private var animationProgress = 0f
    
    /**
     * Recognize a stroke and provide feedback
     */
    fun recognizeStroke(userPath: Path, targetStroke: Stroke): GestureRecognizer.RecognitionResult {
        val result = gestureRecognizer.recognizeStroke(userPath, targetStroke)
        
        // Provide audio feedback
        if (preferenceUtils.isAudioFeedbackEnabled()) {
            if (result.isCompleted) {
                audioUtils.playSoundEffect(AudioUtils.SoundType.CORRECT)
            } else {
                audioUtils.playSoundEffect(AudioUtils.SoundType.INCORRECT)
            }
        }
        
        // Provide haptic feedback
        if (preferenceUtils.isHapticFeedbackEnabled()) {
            if (result.isCompleted) {
                audioUtils.provideHapticFeedback(AudioUtils.HapticFeedbackType.CORRECT)
            } else {
                audioUtils.provideHapticFeedback(AudioUtils.HapticFeedbackType.INCORRECT)
            }
        }
        
        return result
    }
    
    /**
     * Draw guidance for a character based on the current guidance level
     */
    fun drawGuidance(
        canvas: Canvas,
        character: BengaliCharacter,
        currentStrokeIndex: Int,
        guidanceLevel: GuidanceLevel,
        scaleFactor: Float
    ) {
        if (currentStrokeIndex >= character.strokes.size) {
            return
        }
        
        val currentStroke = character.strokes[currentStrokeIndex]
        val dotRadius = context.resources.getDimension(R.dimen.guidance_dot_radius) / scaleFactor
        
        canvas.save()
        canvas.scale(scaleFactor, scaleFactor, 0f, 0f)
        
        when (guidanceLevel) {
            GuidanceLevel.NONE -> {
                // No guidance
            }
            GuidanceLevel.DOTS_ONLY -> {
                // Draw dots for the current stroke
                drawGuidanceDots(canvas, currentStroke, dotRadius)
            }
            GuidanceLevel.DOTS_AND_ARROWS -> {
                // Draw dots and arrows
                drawGuidanceDots(canvas, currentStroke, dotRadius)
                drawGuidanceArrows(canvas, currentStroke)
            }
            GuidanceLevel.FULL_PATH -> {
                // Draw full path with dots and arrows
                drawAllGuidanceDots(canvas, character, currentStrokeIndex, dotRadius)
                drawAnimatedPath(canvas, currentStroke)
            }
        }
        
        canvas.restore()
    }
    
    /**
     * Draw guidance dots for a stroke
     */
    private fun drawGuidanceDots(canvas: Canvas, stroke: Stroke, dotRadius: Float) {
        // Draw start point
        canvas.drawCircle(stroke.startPoint.x, stroke.startPoint.y, dotRadius, guidanceDotPaint)
        
        // Draw end point
        canvas.drawCircle(stroke.endPoint.x, stroke.endPoint.y, dotRadius, guidanceDotPaint)
        
        // Draw order numbers
        canvas.drawText("1", stroke.startPoint.x - dotRadius / 2, stroke.startPoint.y - dotRadius, textPaint)
        canvas.drawText("2", stroke.endPoint.x - dotRadius / 2, stroke.endPoint.y - dotRadius, textPaint)
    }
    
    /**
     * Draw all guidance dots for a character
     */
    private fun drawAllGuidanceDots(canvas: Canvas, character: BengaliCharacter, currentStrokeIndex: Int, dotRadius: Float) {
        // Draw dots for the current stroke
        val relevantDots = character.guidanceDots.filter { dot ->
            // Only show dots relevant to the current stroke
            val strokeDots = character.strokes[currentStrokeIndex].let { stroke ->
                listOf(stroke.startPoint, stroke.endPoint) + stroke.controlPoints
            }
            
            // Check if this dot is close to any point in the current stroke
            strokeDots.any { point ->
                val distance = sqrt(
                    (point.x - dot.x).pow(2) + (point.y - dot.y).pow(2)
                )
                distance < 20f
            }
        }
        
        relevantDots.forEach { dot ->
            canvas.drawCircle(dot.x, dot.y, dotRadius, guidanceDotPaint)
            canvas.drawText(dot.order.toString(), dot.x - dotRadius / 2, dot.y - dotRadius, textPaint)
        }
    }
    
    /**
     * Draw guidance arrows for a stroke
     */
    private fun drawGuidanceArrows(canvas: Canvas, stroke: Stroke) {
        val arrowPath = Path()
        arrowPath.moveTo(stroke.startPoint.x, stroke.startPoint.y)
        
        if (stroke.controlPoints.isEmpty()) {
            // Simple line
            arrowPath.lineTo(stroke.endPoint.x, stroke.endPoint.y)
        } else if (stroke.controlPoints.size == 1) {
            // Quadratic curve
            val cp = stroke.controlPoints[0]
            arrowPath.quadTo(cp.x, cp.y, stroke.endPoint.x, stroke.endPoint.y)
        } else {
            // Cubic curve
            val cp1 = stroke.controlPoints[0]
            val cp2 = stroke.controlPoints[1]
            arrowPath.cubicTo(cp1.x, cp1.y, cp2.x, cp2.y, stroke.endPoint.x, stroke.endPoint.y)
        }
        
        canvas.drawPath(arrowPath, guidancePaint)
        
        // Draw arrow head
        drawArrowHead(canvas, stroke.endPoint.toPointF(), getDirectionPoint(stroke), 10f)
    }
    
    /**
     * Draw an animated path for a stroke
     */
    private fun drawAnimatedPath(canvas: Canvas, stroke: Stroke) {
        val path = PathUtils.strokeToPath(stroke)
        
        // Draw the full path
        canvas.drawPath(path, guidancePaint)
        
        // Start animation if not already running
        if (animationHandler == null) {
            startPathAnimation(stroke)
        }
        
        // Draw animated dot along the path
        val pathMeasure = android.graphics.PathMeasure(path, false)
        val pathLength = pathMeasure.length
        val pos = FloatArray(2)
        val tan = FloatArray(2)
        
        val distance = pathLength * animationProgress
        pathMeasure.getPosTan(distance, pos, tan)
        
        val dotRadius = context.resources.getDimension(R.dimen.guidance_dot_radius) * 1.5f
        canvas.drawCircle(pos[0], pos[1], dotRadius, guidanceDotPaint)
    }
    
    /**
     * Start path animation
     */
    private fun startPathAnimation(stroke: Stroke) {
        animationHandler = Handler(Looper.getMainLooper())
        animationRunnable = object : Runnable {
            override fun run() {
                animationProgress += 0.01f
                if (animationProgress > 1f) {
                    animationProgress = 0f
                }
                
                // Schedule next frame
                animationHandler?.postDelayed(this, 16) // ~60fps
            }
        }
        
        animationProgress = 0f
        animationHandler?.post(animationRunnable!!)
    }
    
    /**
     * Stop path animation
     */
    fun stopAnimation() {
        animationRunnable?.let { animationHandler?.removeCallbacks(it) }
        animationHandler = null
        animationRunnable = null
    }
    
    /**
     * Draw an arrow head
     */
    private fun drawArrowHead(canvas: Canvas, point: PointF, directionPoint: PointF, size: Float) {
        val angle = Math.atan2(
            (point.y - directionPoint.y).toDouble(),
            (point.x - directionPoint.x).toDouble()
        )
        
        val arrowHead = Path()
        arrowHead.moveTo(point.x, point.y)
        arrowHead.lineTo(
            (point.x - size * Math.cos(angle - Math.PI / 6)).toFloat(),
            (point.y - size * Math.sin(angle - Math.PI / 6)).toFloat()
        )
        arrowHead.moveTo(point.x, point.y)
        arrowHead.lineTo(
            (point.x - size * Math.cos(angle + Math.PI / 6)).toFloat(),
            (point.y - size * Math.sin(angle + Math.PI / 6)).toFloat()
        )
        
        canvas.drawPath(arrowHead, guidancePaint)
    }
    
    /**
     * Get the direction point for a stroke
     */
    private fun getDirectionPoint(stroke: Stroke): PointF {
        return if (stroke.controlPoints.isNotEmpty()) {
            val lastControlPoint = stroke.controlPoints.last()
            PointF(lastControlPoint.x, lastControlPoint.y)
        } else {
            PointF(stroke.startPoint.x, stroke.startPoint.y)
        }
    }
    
    /**
     * Draw visual feedback for a stroke attempt
     */
    fun drawStrokeFeedback(canvas: Canvas, path: Path, isCorrect: Boolean, scaleFactor: Float) {
        canvas.save()
        canvas.scale(scaleFactor, scaleFactor, 0f, 0f)
        
        val paint = if (isCorrect) correctPaint else incorrectPaint
        canvas.drawPath(path, paint)
        
        canvas.restore()
    }
    
    /**
     * Release resources
     */
    fun release() {
        stopAnimation()
        audioUtils.release()
    }
    
    companion object {
        private fun sqrt(value: Float): Float = kotlin.math.sqrt(value)
        private fun pow(value: Float, power: Int): Float = value.pow(power)
    }
}

